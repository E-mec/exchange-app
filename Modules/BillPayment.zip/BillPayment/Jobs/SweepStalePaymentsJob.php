<?php

namespace Modules\BillPayment\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Modules\BillPayment\actions\VerifyBillPaymentAction;
use Modules\BillPayment\Enums\BillStatusEnum;
use Modules\BillPayment\Models\BillPayment;

class SweepStalePaymentsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle(VerifyBillPaymentAction $verify): void
    {
        // Any payment stuck in PROCESSING for more than 10 minutes
        BillPayment::where('status', BillStatusEnum::PROCESSING)
            ->where('updated_at', '<=', now()->subMinutes(10))
            ->each(fn (BillPayment $payment) => $verify->handle($payment));
    }
}
