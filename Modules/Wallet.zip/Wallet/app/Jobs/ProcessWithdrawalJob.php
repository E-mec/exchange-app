<?php

namespace Modules\Wallet\app\Jobs;

use App\Exceptions\CustomException;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Modules\Wallet\app\Interfaces\PayoutProvider;
use Modules\Wallet\app\Events\WithdrawalSucceeded;
use Modules\Wallet\app\Events\WithdrawalFailed;
use Modules\Wallet\Models\Withdrawal;

class ProcessWithdrawalJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $maxAttempts = 3;
    public int $backoff = 60; // 60 seconds between retries

    public function __construct(
        public readonly string $withdrawalReference,
    ) {}

    /**
     * Execute the job.
     */
    public function handle(PayoutProvider $provider): void
    {
        $withdrawal = Withdrawal::query()
            ->where('reference', $this->withdrawalReference)
//            ->lockForUpdate()
            ->first();

        if (!$withdrawal) {
            throw new CustomException("Withdrawal with reference {$this->withdrawalReference} not found");
        }

//        try {
            // Call external provider to process the payout
            $providerResponse = $provider->execute([
                'amount' => $withdrawal->amount,
                'currency' => $withdrawal->currency,
                'destination' => $withdrawal->meta['destination'] ?? [],
                'reference' => $withdrawal->reference,
            ]);

            // Store provider reference
            $withdrawal->update([
                'provider_reference' => $providerResponse['reference'] ?? null,
                'meta' => array_merge(
                    $withdrawal->meta ?? [],
                    ['provider_response' => $providerResponse]
                ),
            ]);

            // Dispatch success event
            WithdrawalSucceeded::dispatch($withdrawal->reference);

//        } catch (\Exception $exception) {
//            report($exception);
//
//            // If this is the last attempt, dispatch failure event
//            if ($this->attempts() >= $this->maxAttempts) {
//                WithdrawalFailed::dispatch(
//                    $withdrawal->reference,
//                    $exception->getMessage()
//                );
//            } else {
//                // Retry with backoff
//                $this->release($this->backoff);
//            }
//        }
    }

    public function failed(\Throwable $exception): void
    {
        // Only called after all attempts are exhausted
        WithdrawalFailed::dispatch($this->withdrawalReference, $exception->getMessage());
    }
}
